let MultiverseCollapse = {
  stars() {
    return Decimal.pow(2, Math.pow(2, 48));
  }
}
