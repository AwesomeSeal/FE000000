Yeah, I know this is a complete ripoff of AD.

Some buttons are annoying to press in Safari, due to clicking spans in buttons with rapidly changing text not being considered a type of clicking the button in question in Safari. I generally like Safari and expect other browsers might also have this problem, so I'll try to fix it somehow. However, Chrome seems to work, so if anyone is actually playing this, you should probably use Chrome unless and until I find a fix.
